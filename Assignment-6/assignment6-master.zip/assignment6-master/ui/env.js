/* eslint-disable linebreak-style */

// eslint-disable-next-line no-undef
window.ENV = {
  UI_API_ENDPOINT: 'http://localhost:3000/graphql',
};
